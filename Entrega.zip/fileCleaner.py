#lang python

def remplazo(txt):
    newTxt = txt.replace('\\"', "")
    newTxt2 = newTxt.replace("<span class = 'SEP'>\\\\r\\\\n</span>", "<br>")
    newTxt2 = newTxt2.replace("'", '')
    return(newTxt2)

def remplazo2(txt):
    newTxt2 = txt.replace("\\\\", '"')
    newTxt2 = newTxt2.replace("\\", '')
    newTxt2 = newTxt2.replace('"', "'")
    newTxt2 = newTxt2.replace("'r'n","<br>")
    newTxt2 = newTxt2.replace("<br>&nbsp;","<br>")
    return(newTxt2)

def anadir(txt):
    if "ERROR" in txt:
        txt2 = "<p class='MensajeError'>Error: Caractér no identificado alfaa </p>"
    else:
        txt2 = "<p class='MensajeError'>Copyright (C) Softboy Corporation. Todos los derechos reservados<br>PS C: alfaa </p> "
    return(txt2)

def anadir2(txt):
    if "ERROR" in txt:
        txtS = ""
        txt2 = txt + "</p><section class = consola><p class='MensajeError'>Error: Caractér no identificado alfaa</p></section>"
    else:
        txt2 = txt + "</p><section class = consola><p class='MensajeError'>Copyright (C) Softboy Corporation. Todos los derechos reservados<br>PS C: alfaa</p></section>"
    return(txt2)

txts = []
ar = ""
listaVar = []
listaVar2 = []
listaVar3 = []
error="Errores:"
listaoperadores = ['=','+','-','*','/','^','<','>']

def errorSin(txt):
    error="No hay error"
    for i in range(len(txt)):
        if txt[i] == "F" and txt[i+1] == "O" and txt[i+2] == "R":
            if txt[i+34] == "V" and txt[i+35] == "A" and txt[i+36] == "R":
                if txt[i+42] == ">":
                    j = i+43
                    while txt[j] != "&":
                        listaVar.append(txt[j])
                        j+=1
                    newpos=j+27
                    if txt[newpos] == "I" and txt[newpos+1] == "N":
                        if txt[newpos+32] == "R" and txt[newpos+33] == "A" and txt[newpos+34] == "N" :
                            if txt[newpos+70] == "P" and txt[newpos+71] == "A"and txt[newpos+80] == "A"and txt[newpos+81] == "B":
                                if txt[newpos+116] == "V" and txt[newpos+117] == "A" and txt[newpos+118] == "R":
                                    k = newpos+124
                                    while txt[k] != "&":
                                        listaVar2.append(txt[k])
                                        k+=1
                                    newpos2=k+27
                                    if txt[newpos2] == "P" and txt[newpos2+1] == "A" and txt[newpos2+10] == "C":
                                        if txt[newpos2+46] == "D" and txt[newpos2+47] == "O" and txt[newpos2+48] == "S":
                                            break
                                        else:
                                            error="Error, faltan dos puntos en el ciclo for"
                                            txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                                    else:
                                        error="Error, falta cerrar paréntesis"
                                elif txt[newpos+116] == "E" and txt[newpos+117] == "N" and txt[newpos+118] == "T":
                                    k = newpos+124
                                    while txt[k] != "&":
                                        listaVar2.append(txt[k])
                                        k+=1
                                    newpos2=k+27
                                    if txt[newpos2] == "P" and txt[newpos2+1] == "A" and txt[newpos2+10] == "C":
                                        if txt[newpos2+46] == "D" and txt[newpos2+47] == "O" and txt[newpos2+48] == "S":
                                            break
                                        else:
                                            error="Error, faltan dos puntos en el ciclo for"
                                            txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                                    else:
                                        error="Error, falta cerrar paréntesis"
                                elif txt[newpos+116] == "R" and txt[newpos+117] == "E" and txt[newpos+118] == "A":
                                    k = newpos+124
                                    while txt[k] != "&":
                                        listaVar2.append(txt[k])
                                        k+=1
                                    newpos2=k+27
                                    if txt[newpos2] == "P" and txt[newpos2+1] == "A" and txt[newpos2+10] == "C":
                                        if txt[newpos2+46] == "D" and txt[newpos2+47] == "O" and txt[newpos2+48] == "S":
                                            break
                                        else:
                                            error="Error, faltan dos puntos en el ciclo for"
                                            txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                                    else:
                                        error="Error, falta cerrar paréntesis"
                                else:
                                    error="Error, argumento inválido para función 'range'"
                                    txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                            else:
                                error="Error, falta parentesis"
                        
                        elif txt[newpos+32] == "V" and txt[newpos+33] == "A" and txt[newpos+34] == "R" :
                            k = newpos+41
                            while txt[k] != "&":
                                listaVar2.append(txt[k])
                                k+=1
                            newpos2=k+27
                            if txt[newpos2] == "D" and txt[newpos2+1] == "O" and txt[newpos2+2] == "S":
                                break
                            else:
                                error="Faltan dos puntos en la secuencía de for"
                                txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                        elif txt[newpos+32] == "E" and txt[newpos+33] == "N" and txt[newpos+34] == "T" :
                            k = newpos+41
                            while txt[k] != "&":
                                listaVar2.append(txt[k])
                                k+=1
                            newpos2=k+27
                            if txt[newpos2] == "D" and txt[newpos2+1] == "O" and txt[newpos2+2] == "S":
                                break
                            else:
                                error="Faltan dos puntos en la secuencía de for"
                                txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")

                        else:
                            error="Error de Sintaxis, uitiliza la función 'range' o una variable"
                            txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
                    else:
                        error="Error, no hay IN despues de la variable" 
                        txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
            else:
                error="Error, no hay variable después del for"
                txt=txt.replace("<span class = FOR>for&nbsp;</span>", "<span class = ERROR class = FOR>for&nbsp;</span>")
#Print
    for i in range(len(txt)):
        if txt[i] == "P" and txt[i+1] == "R" and txt[i+2] == "I"and txt[i+3] == "N"and txt[i+4] == "T":
            if txt[i+38] == "P" and txt[i+39] == "A"and txt[i+48] == "A"and txt[i+49] == "B":
                if txt[i+84] == "V" and txt[i+85] == "A" and txt[i+86] == "R":
                    k = i+93
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "S" and txt[i+85] == "T" and txt[i+86] == "R":
                    k = i+93
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "E" and txt[i+85] == "N" and txt[i+86] == "T":
                    k = i+91
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "R" and txt[i+85] == "E" and txt[i+86] == "A":
                    k = i+89
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                else:
                    error="Error, argumento no válido para la función 'print'"
                    txt = txt.replace("<span class = PRINT>print&nbsp;</span>", "<span class = ERROR class = PRINT>print&nbsp;</span>")
            else:
                error="Error, falta parentesis"
#Import
    for i in range(len(txt)):
        if txt[i] == "I" and txt[i+1] == "M" and txt[i+2] == "P"and txt[i+3] == "O"and txt[i+4] == "R":
            if txt[i+40] == "V" and txt[i+41] == "A" and txt[i+42] == "R":
                if txt[i+48] == ">":
                    j = i+49
                    while txt[j] != "&":
                        listaVar.append(txt[j])
                        j+=1
                    newpos=j+27
            else:
                error="Error, argumento no válido para función 'import'"
                txt = txt.replace("<span class = IMPORT>import&nbsp;</span>", "<span class = ERROR class = IMPORT>import&nbsp;</span>")
#From
    for i in range(len(txt)):
        if txt[i] == "F" and txt[i+1] == "R" and txt[i+2] == "O"and txt[i+3] == "M":
            if txt[i+36] == "V" and txt[i+37] == "A" and txt[i+38] == "R":
                if txt[i+44] == ">":
                    j = i+45
                    while txt[j] != "&":
                        listaVar.append(txt[j])
                        j+=1
                    newpos=j+27
                    if txt[newpos] == "I" and txt[newpos+1] == "M" and txt[newpos+2] == "P"and txt[newpos+3] == "O"and txt[newpos+4] == "R":
                        if txt[newpos+40] == "V" and txt[newpos+41] == "A" and txt[newpos+42] == "R":
                            if txt[newpos+48] == ">":
                                j = newpos+49
                                while txt[j] != "&":
                                    listaVar.append(txt[j])
                                    j+=1
                                newpos2=j+27
                                break
                        else:
                            error="Error, argumento no válido para función 'import'"
                            txt = txt.replace("<span class = IMPORT>import&nbsp;</span>", "<span class = ERROR class = IMPORT>import&nbsp;</span>")
                    else:
                        error="Error, falta función 'import'"
                        txt = txt.replace("<span class = FROM>from&nbsp;</span>","<span class = ERROR class = FROM>from&nbsp;</span>")
            else:
                error="Error, argumento no válido para función 'from'"
                txt = txt.replace("<span class = FROM>from&nbsp;</span>","<span class = ERROR class = FROM>from&nbsp;</span>")
    #Return
    for i in range(len(txt)):
        if txt[i] == "R" and txt[i+1] == "E" and txt[i+2] == "T"and txt[i+3] == "U"and txt[i+4] == "R":
            if txt[i+40] == "P" and txt[i+41] == "A"and txt[i+50] == "A"and txt[i+51] == "B":
                if txt[i+86] == "V" and txt[i+87] == "A" and txt[i+88] == "R":
                    k = i+95
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "S" and txt[i+85] == "T" and txt[i+86] == "R":
                    k = i+93
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "E" and txt[i+85] == "N" and txt[i+86] == "T":
                    k = i+91
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                elif txt[i+84] == "R" and txt[i+85] == "E" and txt[i+86] == "A":
                    k = i+89
                    while txt[k] != "&":
                        listaVar3.append(txt[k])
                        k+=1
                    newpos=k+27
                    if txt[newpos] == "P" and txt[newpos+1] == "A" and txt[newpos+10] == "C":
                        break
                    else:
                        error="Error, falta parentesis"
                else:
                    error="Error, argumento no válido para la función 'return'"
                    txt = txt.replace("<span class = RETURN>return&nbsp;</span>", "<span class = ERROR class = RETURN>return&nbsp;</span>")
            else:
                error="Error, falta parentesis"


    #error2 = "<section class = consola><p class='MensajeError'>"+error+"</p></section>"
    error1="<br>"+"Errores de Sintaxis: "+error
    txt = txt.replace("alfaa",error1)
    #txt +=error2
    return(txt)

  
